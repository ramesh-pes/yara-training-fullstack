import AsyncStorage from '@react-native-community/async-storage';
const API_BASEURL = 'http://localhost:4000/api/customer';
const API_LOGIN = 'http://localhost:4000/users/authenticate';
    var token = null;
    export var setToken = function(newToken){
        token = newToken;
        AsyncStorage.setItem('token', newToken);
      }
      export var removeToken = function(){
        AsyncStorage.removeItem('token');
        token = null;
      }  
    export var getToken = function(){
        return token;
    }
    export var doLogin = async function(email,password){
        console.log('email:'+email);
        console.log('password:'+password);
        let response = await fetch(API_LOGIN,{
            method:"POST",
            body:JSON.stringify({email:email,password:password}),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });
        let result = await response.json();
        console.log(JSON.stringify(result));
        return result;
      }  
    export var getCustomers = async function(){
        let response = await fetch(API_BASEURL,{
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-access-token':token
                }
        });
        let customers = await response.json();
        console.log(JSON.stringify(customers));
        return customers;
      }
      export var deleteCustomer = async function(id){
        console.log("deleteCustomer:"+id);
        let response = await fetch(API_BASEURL,{
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-access-token':token
             },
            method:"delete",
            body:JSON.stringify({id:id})
        });
        let result = await response.json(); 
        return result;
    } 
    export var getCustomerById = async function(id){
        console.log("getCustomerById:"+id);
        let response = await fetch(API_BASEURL+"/"+id,{
            headers: {
                'x-access-token':token
             }
        });
        let result = await response.json(); 
        return result;
    } 
    export var addCustomer = async function(customer){
        console.log("addCustomer:");
        let response = await fetch(API_BASEURL,{
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-access-token':token
             },
            method:"post",
            body:JSON.stringify(customer)
        });
        let result = await response.json(); 
        return result;
    } 
    export var updateCustomer = async function(customer){
        console.log("updateCustomer:"+JSON.stringify(customer));
        let response = await fetch(API_BASEURL,{
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-access-token':token
             },
            method:"put",
            body:JSON.stringify(customer)
        });
        let result = await response.json(); 
        return result;
    } 