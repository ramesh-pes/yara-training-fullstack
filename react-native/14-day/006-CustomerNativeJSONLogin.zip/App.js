import * as React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Login from './src/container/Login';
import Customers from './src/container/Customers';
import Movies from './src/container/Movies';
import Menu from './src/components/AppMenu';
import AddCustomer from './src/container/AddCustomer';
import AboutScreen from './src/container/About';
import AsyncStorageExample from './src/container/AsyncStorage';
import AsyncStorage from '@react-native-community/async-storage';
import {setToken} from './src/service/CustomerAPI'
function LoadingScreen(props) {
  return (
    <View style={{ flex: 1, alignItems: 'center'}}>
      <Text>Loading Customer App..</Text>
    </View>
  );
}
var token = null;
const Stack = createStackNavigator();
function App() {
  const [isTokenRetrived, setTokenEvent] = React.useState(false);
  React.useEffect(()=>{
    if(!isTokenRetrived){
      AsyncStorage.getItem('token').then(
        (value) => {
          token = value;
          setToken(token);
          setTokenEvent(true)
          console.log("token is "+token);
        });
    }
  });
  if(!isTokenRetrived){
    return (
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name=" " component={LoadingScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    );
  }else if(token != null && token.length > 20){
    return (
      <NavigationContainer>
        <Stack.Navigator>
        <Stack.Screen name="Customers" component={Customers} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="AddCustomer" options={{ title: 'Add Customer' }} component={AddCustomer} />
        <Stack.Screen name="Movies" component={Movies} />
        <Stack.Screen name="Home" component={AsyncStorageExample} />
        <Stack.Screen name="About" component={AboutScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    );
  } else{
    return (
      <NavigationContainer>
        <Stack.Navigator>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="AddCustomer" options={{ title: 'Add Customer' }} component={AddCustomer} />
        <Stack.Screen name="Customers" component={Customers} />
        <Stack.Screen name="Movies" component={Movies} />
        <Stack.Screen name="Home" component={AsyncStorageExample} />
        <Stack.Screen name="About" component={AboutScreen} />
        </Stack.Navigator>
    </NavigationContainer>
    );
  }
}
export default App;
