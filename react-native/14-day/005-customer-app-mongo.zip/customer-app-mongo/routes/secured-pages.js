var express = require('express');
var router = express.Router();
var customerModel = require('../model/customer');
var customerMySQL = require('../model/customer-mysql');
var customerMongo = require('../model/customer-mongo');

// /rama + /home = /rama/home
router.get('/home', function(req, res, next) {
  res.render('home', { title: 'Home Page',email:req.session.user });
});

router.get('/about', function(req, res, next) {
  res.render('home', { title: 'About',email:req.session.user });
});

router.get('/student', function(req, res, next) {
  res.render('home', { title: 'Student',email:req.session.user });
});

router.get('/customer', function(req, res, next) {
  let callback = (records)=>{
    res.render('customer', { title: 'Customers' , customers:records,email:req.session.user});
  }
  customerMongo.getCustomersPromise().then(callback); 
});

router.get('/customer/add', function(req, res, next) {
  res.render('customerAdd', { title: 'Add Customer' , customers:customerModel.getRecords() });
});

router.get('/customer/search/:field/:text', function(req, res, next) {
  let callback = (records) =>res.render('customer', 
  	{ title: 'Customers', 
  	customers:records,email:req.session.user});
  customerMongo.getCustomersBySearch(req.params.field,req.params.text).then(callback);
});

router.get('/customer/edit/:id', function(req, res, next) {
	console.log("id:"+req.params.id);
  let callback = (record)=> {
    res.render('customerEdit', { title: 'Update Customer', customer: record});
  }
  customerMongo.getCustomerById(req.params.id).then(callback);
  
});

module.exports = router;












