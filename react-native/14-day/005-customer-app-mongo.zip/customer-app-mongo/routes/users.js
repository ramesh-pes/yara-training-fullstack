var jwt    = require('jsonwebtoken'); // used to create, sign, and verify tokens
var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/login', function(req, res, next) {
  console.log(JSON.stringify(req.body));
  if(req.body.email != undefined && req.body.email!="" 
    && req.body.email == req.body.password){
    req.session.user = req.body.email;
    res.send({result:'success', msg:"login successful" });
  }else{
    res.send({result:'fail', msg:"Incorrect uername or password." });
  }
});

router.post('/authenticate', function(req, res, next) {
  console.log(JSON.stringify(req.body));
  if(req.body.email != undefined && req.body.email!="" 
  	&& req.body.email == req.body.password){
      var payload = {
        admin: req.body.email	
      }
      //generating token
      var token = jwt.sign(payload,"trainingIsGood", {
        expiresIn: 86400 // expires in 24 hours
      });
      res.json({
        result:'success',
        success: true,
        message: 'Enjoy your token!',
        token: token
      });
  }else{
  	res.send({result:'fail', msg:"Incorrect uername or password." });
  }
});

module.exports = router;