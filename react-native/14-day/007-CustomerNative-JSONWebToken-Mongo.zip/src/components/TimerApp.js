import React, { Component,useState,useEffect } from 'react';
import { TextInput, View,Text, Button } from 'react-native';

const TimerApp = () => {
  const [value, onChangeText] = React.useState('Useless Placeholder');
  const [init, setInit] = React.useState(false);
  const [counter, setCounter] = useState(0); //this is not private React way to bind var with GUI
  //var interval;
  var myCount = 0;

  useEffect(()=>{/*
      if(!init){
        setInit(true);
        interval = setInterval(() => { 
          console.log("count is "+myCount);
          setCounter(myCount++)}, 
          1000);
      }*/
  })
  return (
    <View>
        <Text>{counter}</Text>
        <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1 }}
        onChangeText={text => onChangeText(text)}
        value={value}
        />
        <Button title='Count' onPress={()=>{setCounter(counter+1)}} ></Button>
    </View>
  );
}

export default TimerApp;