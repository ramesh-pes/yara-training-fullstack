import React from 'react';
import { StyleSheet, Text, View,Button } from 'react-native';
import {removeToken} from '../service/CustomerAPI';

export default class AppMenu extends React.Component {
  constructor(props) {
    super()
  }
  render() {
    return (
      <View style={{flexDirection: 'row'}}>
      <Button
        onPress={() => this.props.navigation.navigate('Home')}
        title="Home"
      />
      <Button
      onPress={() => this.props.navigation.navigate('About')}
      title="About"
    />
      <Button
        onPress={() => this.props.navigation.navigate('Movies')}
        title="Movies"
      />
      <Button
         onPress={() => this.props.navigation.navigate('Customers')}
        title="Customers"
      />
      <Button
        onPress={() => {
          removeToken();
          this.props.navigation.navigate('Login');}
        }
        title="Logout"
      />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});