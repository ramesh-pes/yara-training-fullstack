var express = require('express');
var router = express.Router();
var customerModel = require('../model/customer');
var customerMySQL = require('../model/customer-mysql');
var customerMongo = require('../model/customer-mongo');

router.get('/', function (req, res) {
	let callback = (records) =>{
		console.log("records"+records);
		res.send(records);
	}
	//customerMySQL.getCustomers().then(callback);
	customerMongo.getCustomersPromise().then(callback);
});

router.get('/all', function (req, res) {
	let callback = (records) =>{
		res.send(records);
	}
	customerMongo.getCustomersPromise().then(callback);
});

router.get('/:id', function(req, res, next) {
  customerMongo.getCustomerById(req.params.id).then((result)=>res.send(result));
});

router.get('/search/:field/:text', function(req, res, next) {
  let callback = (records) =>res.send(records);
  customerMongo.getCustomersBySearch(req.params.field,req.params.text).then(callback);
});

router.put('/', function (req, res) {
	let customer = req.body;
	let callback = (result) => { res.send(result); };
	customerMongo.updateCustomer(customer).then(callback);
});

router.delete('/', function (req, res) {
	let customer = req.body;
	customerMongo.deleteCustomer(customer.id).then((result)=> {
		res.send(result);
	})	
});

router.post('/', function (req, res) {
	console.log("post .. customer");
	let callback = (result) => res.send(result);
	customerMongo.addCustomer(req.body).then(callback);
});

module.exports = router;








