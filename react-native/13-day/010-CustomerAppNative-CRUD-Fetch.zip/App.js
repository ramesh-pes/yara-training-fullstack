import * as React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Login from './src/container/Login';
import Customers from './src/container/Customers';
import Movies from './src/container/Movies';
import Menu from './src/components/AppMenu';
import AddCustomer from './src/container/AddCustomer';

function HomeScreen(props) {
  return (
    <View style={{ flex: 1, alignItems: 'center'}}>
      <Menu  navigation={props.navigation}/>
      <Text>Home Screen</Text>
    </View>
  );
}

function AboutScreen(props) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <Menu  navigation={props.navigation}/>
      <Text>About Screen</Text>
    </View>
  );
}

const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="AddCustomer" options={{ title: 'Add Customer' }} component={AddCustomer} />
      <Stack.Screen name="Customers" component={Customers} />
      <Stack.Screen name="Movies" component={Movies} />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="About" component={AboutScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
export default App;
