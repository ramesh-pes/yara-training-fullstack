import React from 'react';

class Foo extends React.Component {
  render() {
    return (
      <p>I am not a very smart component...</p>
    );
  }
}

export default Foo;
