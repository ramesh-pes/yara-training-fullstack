import React from 'react';
import Main from './Main';

const Root = ({ route }) => (
  <Main routes={route.routes} />
)

export default Root;
