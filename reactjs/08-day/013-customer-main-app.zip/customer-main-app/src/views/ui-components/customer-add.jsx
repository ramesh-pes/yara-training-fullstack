import React, { useState,useEffect } from 'react';
import {Col,Form, FormGroup, Label, Input, Button } from 'reactstrap';
const apiEndPoint = "http://localhost:4000/api/customer";
const AddCustomer = (props) => {
    // For Dismiss Button with Alert
    const [visible, setVisible] = useState(true);
    //**const [loaded, setLoaded] = useState(false);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [city,setCity] = useState('');
    const [address, setAddress] = useState('');
    const [fetched, setFetched] = useState(false);
    const [id, setId] = useState(0);
    const [label, setLabel] = useState('Add Customer');
  
    useEffect(()=>{
        if(props.match.params.id != undefined && !fetched){
           setFetched(true);
           setLabel('Update Customer');
           fetch(apiEndPoint+"/"+props.match.params.id)
           .then(res => res.json())
           .then(function(result){
              setName(result.name);
              setAddress(result.address);
              setCity(result.city);
              setPhone(result.phone);
              setEmail(result.email);
              setId(result.id);
              console.log(JSON.stringify(result));
              })  
        }
     })//useEffect(
        var addUpdateCutomer=(e) =>{
            e.preventDefault();
            let methodType = 'post';
            var customer = {
               name:name,
               email:email,
               phone:phone,
               city:city,
               address:address
            };
            if(id!=0){ //to update
               methodType = 'put';
               customer.id=id;
            }
            fetch(apiEndPoint,{
               method: methodType,
               body:JSON.stringify(customer),
               headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json'
               }
            }) .then(function(result){
                  console.log("record added.");
                  props.history.push('/customer');
               })            
         };
         var onHandleChange=(e)=>{
            console.log("e.target.name:"+e.target.name);
            if(e.target.name == 'email'){
               setEmail(e.target.value);
            } else if(e.target.name == 'name'){
               setName(e.target.value);
            } else if(e.target.name == 'phone'){
               setPhone(e.target.value);
            } else if(e.target.name == 'address'){
               setAddress(e.target.value);
            }else if(e.target.name == 'city'){
               setCity(e.target.value);
            }
         }
    return (<div style={{margin:'10%'}} >
    <h3>Add Customer</h3>
    <Form>
    <FormGroup row>
        <Label for="exampleName" sm={2}>Name</Label>
        <Col sm={10}>
          <Input onChange={onHandleChange} type="text" value={name} name="name" id="exampleName" placeholder="with a placeholder" />
        </Col>
      </FormGroup>
      <FormGroup row>
        <Label for="examplemail" sm={2}>Email</Label>
        <Col sm={10}>
          <Input onChange={onHandleChange} type="text" value={email} name="email" id="exampleEmail" placeholder="with a placeholder" />
        </Col>
      </FormGroup>
      <FormGroup row>
        <Label for="examplePhone" sm={2}>Phone</Label>
        <Col sm={10}>
          <Input onChange={onHandleChange} type="text" value={phone} name="phone" id="examplePhone" placeholder="with a placeholder" />
        </Col>
      </FormGroup>
      <FormGroup row>
        <Label for="exampleName" sm={2}>Name</Label>
        <Col sm={10}>
          <Input onChange={onHandleChange} type="text" value={address} name="address" id="exampleAddress" placeholder="Enter Address" />
        </Col>
      </FormGroup>

    <Button  onClick={addUpdateCutomer}  variant="primary" type="submit">
       {label}
    </Button>
    </Form>
 </div>
);
}
export default AddCustomer;
