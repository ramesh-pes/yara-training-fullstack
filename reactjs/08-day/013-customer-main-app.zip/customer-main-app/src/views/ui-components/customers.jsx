import React, { useState,useEffect } from 'react';
import {
    Alert,
    UncontrolledAlert,
    Card,
    CardBody,
    CardTitle,
    Button,
    Table
} from 'reactstrap';
const apiEndPoint = "http://localhost:4000/api/customer";
const Customers = (props) => {
    // For Dismiss Button with Alert
    const [visible, setVisible] = useState(true);
    const [loaded, setLoaded] = useState(false);
    const [customers, setCustomers] = useState([]);
    var doDelete = (id) => {
       setLoaded(false);
       fetch(apiEndPoint,{
          method: 'delete',
          body:JSON.stringify({id:id}),
          headers: {
             'Accept': 'application/json',
             'Content-Type': 'application/json'
          }
       })
          .then(function(result){
             console.log("record deleted.")
          })
    }
    var doEdit = (id) => {
       props.history.push('/customer/edit/'+id);
    }
    var callbackSuccess =(result)=>{
       //console.log(JSON.stringify(result));
       setCustomers(result);
    }
    var callbackError =(error)=>{
       console.log("Error:");
    }
    useEffect((e) => { 
       console.log(e);
       if(!loaded){
          setLoaded(true);
          fetch(apiEndPoint)
             .then(res => res.json())
             .then(callbackSuccess,callbackError)
       }
    });

    const onDismiss = () => {
        setVisible(false);
    }

    return (
        <div>
              <Card>
                <CardTitle className="bg-light border-bottom p-3 mb-0">
                    <i className="mdi mdi-comment-processing-outline mr-2"> </i>
            Customers X
          </CardTitle>
                <CardBody className="">
            <Button onClick={()=>{
               props.history.push('/customer/add');
            }  
            }>Add Customer</Button> <br/><br/>
            <Table striped bordered hover size="sm">
               <thead>
                  <tr>
                     <th>#</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Phone</th>
                              <th>Address</th>
                              <th>Edit</th>
                              <th>Delete</th>
                  </tr>
               </thead>
               <tbody>
               {customers.map(item => (
                           <tr key={item.id}>
                              <td>{item.id}</td>
                              <td>{item.name}</td>
                              <td>{item.email}</td>
                              <td>{item.phone}</td>
                              <td>{item.address}</td>
                              <td><Button variant="info" onClick={()=>{ doEdit(item.id)}}>edit</Button></td>
                              <td><Button variant="danger"  onClick={()=>{ doDelete(item.id)}}>delete</Button></td>
                           </tr>
                     ))}

               </tbody>
               </Table>
                </CardBody>
            </Card>
        </div>
    );
}

export default Customers;
