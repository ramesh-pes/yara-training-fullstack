import Fulllayout from '../layouts/fulllayout.jsx';
import CustomerAdd from '../views/ui-components/customer-add.jsx';

var indexRoutes = [
    { path: '/customer/edit/:id', component: CustomerAdd},
    { path: '/', name: 'Starter', component: Fulllayout },
];

export default indexRoutes;
