import React from 'react';


const Footer = () => {
    return (
        <footer className="footer text-center">
            Designed and Developed by{' '}
            <a href="https://www.pyther.com">Pyther Innovations Private Limited</a>.
        </footer>
    );
}
export default Footer;
