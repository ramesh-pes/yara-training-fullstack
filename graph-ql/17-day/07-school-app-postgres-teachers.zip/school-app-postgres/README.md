## Project setup
```
npm install
```

### Run
```
node app.js
```
