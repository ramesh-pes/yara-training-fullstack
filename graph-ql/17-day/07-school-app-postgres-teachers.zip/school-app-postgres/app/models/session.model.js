module.exports = (sequelize, Sequelize) => {
    const Session = sequelize.define("session", {
      name: {
        type: Sequelize.STRING
      },
      start: {
        type: Sequelize.DATE
      },
      duration: {
        type: Sequelize.STRING
      },
      subjectId: {
        type: Sequelize.INTEGER,
        references:{
          model: 'subjects',
          key: 'id'
        }
      },
      teacherId: {
        type: Sequelize.INTEGER,
        references:{
          model: 'teachers',
          key: 'id'
        }
      }
    });
    return Session;
  };
  
    