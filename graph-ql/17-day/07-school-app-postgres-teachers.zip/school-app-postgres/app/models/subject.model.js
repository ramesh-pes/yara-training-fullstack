module.exports = (sequelize, Sequelize) => {
  const Subject = sequelize.define("subject", {
    name: {
      type: Sequelize.STRING
    },
    standard: {
      type: Sequelize.STRING
    },
    section: {
      type: Sequelize.STRING
    },
    toc: {
      type: Sequelize.STRING
    }
  });
  return Subject;
};
