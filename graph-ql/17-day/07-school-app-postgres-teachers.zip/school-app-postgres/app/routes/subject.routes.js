module.exports = app => {
    const recordController = require("../controllers/subject.controller.js");
    var router = require("express").Router();

    router.post("/", recordController.create);

    router.get("/", recordController.findAll);
  
    router.get("/:id", recordController.findOne);
  
    router.put("/:id", recordController.update);
  
    router.delete("/:id", recordController.delete);
  
    router.delete("/", recordController.deleteAll);
  
    app.use("/api/subjects", router);
  };