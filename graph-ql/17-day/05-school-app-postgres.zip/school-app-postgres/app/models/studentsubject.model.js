module.exports = (sequelize, Sequelize) => {
    const StudentSubject = sequelize.define("studentsubject",{
      subjectId: {
        type: Sequelize.INTEGER,
        references:{
          model: 'subjects',
          key: 'id'
        }
      },
      studentId: {
        type: Sequelize.INTEGER,
        references:{
          model: 'students',
          key: 'id'
        }
      },
    });
    return StudentSubject;
    };
    