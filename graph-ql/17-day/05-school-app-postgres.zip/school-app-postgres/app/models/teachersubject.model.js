module.exports = (sequelize, Sequelize) => {
const TeacherSubject = sequelize.define("teachersubject",{
  subjectId: {
    type: Sequelize.INTEGER,
    references:{
      model: 'subjects',
      key: 'id'
    }
  },
  teacherId: {
    type: Sequelize.INTEGER,
    references:{
      model: 'teachers',
      key: 'id'
    }
  },
});
return TeacherSubject;
};
