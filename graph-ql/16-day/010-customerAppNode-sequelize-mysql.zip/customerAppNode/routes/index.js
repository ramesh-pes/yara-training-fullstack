var express = require('express');
var router = express.Router();
const Customer = require('../models/customer');
const { Sequelize } = require('sequelize');

/* GET home page. */
router.get('/', (req, res, next)  => {
  //res.render('index', { title: 'Customer App', company:"IBM"});
  res.redirect("/login");
});

// Ecma Standard + Type + few things  = TypeScript
// JavaScript = Ecma Standard 

// abc = function (req, res, next){}
// abc =(req, res, next) => {}; //arrow 
router.get('/login', (req, res, next) => {
  //res.send(""); //data
  //res.send({result:'success', msg:""}); //data
  res.render('login', { title: 'Login'});
});

router.get('/customer/add', (req, res, next) => {
  res.render('customer-add', { title: 'Add Customer'});
});

router.get('/customer/:field/:searchText', async (req, res, next) => {
  const Op = Sequelize.Op;
  let data = await Customer.findAll({
    where: {
      [req.params.field]: {
        [Op.like]: '%'+req.params.searchText+'%'
      }
    }
  });
  res.render('customers', { title: 'Customers',data:data});
});

router.get('/customer/edit/:id', async (req, res, next) => {
    await Customer.findOne({
        where:{id:req.params.id}
    }).then((customer)=>{
        res.render('customer-edit', { title: 'Update Customer', customer:customer});
  })
 // res.send(model.getCustomerById(req.params.id));
});

router.get('/dashboard', (req, res, next) => {
  res.render('dashboard', { title: 'Dashboard'});
});

router.get('/customer', async(req, res, next) => {
  console.log("/customer ...");
  await Customer.findAll().then((result)=>{
    res.render('customers', { title: 'Customers',data:result});
  })
});

router.get('/about', (req, res, next) => {
  res.render('dashboard', { title: 'About'});
});

module.exports = router;
