const { Sequelize, DataTypes } = require('sequelize');
//const sequelize = new Sequelize('sqlite::memory:');
const sequelize = new Sequelize(
  'nodejs',
  'root', 
  'smartant', {
  host: 'localhost',
  dialect: 'mysql'
});
const Person = sequelize.define('Person', {
  // Model attributes are defined here
  id: {
    type: DataTypes.NUMBER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  name: {
    type: DataTypes.STRING,
    validate: {
          is: ["[a-z]",'i']       // will only allow letters                // only allow values <= 23
        },
  },
  email: {
    type: DataTypes.STRING
  },
  address: {
    type: DataTypes.STRING
  },
  phone: {
    type: DataTypes.STRING
  },  
  country: {
    type: DataTypes.STRING
  }
}, {
  tableName: 'people'
});

module.exports = Person;