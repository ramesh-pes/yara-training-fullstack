const { Sequelize, DataTypes } = require('sequelize');
//const sequelize = new Sequelize('sqlite::memory:');
const sequelize = new Sequelize(
  'nodejs',
  'root', 
  'smartant', {
  host: 'localhost',
  dialect: 'mysql'
});
const Customer = sequelize.define('Customer', {
  // Model attributes are defined here
  id: {
    type: DataTypes.NUMBER,
    autoIncrement: true,
    primaryKey: true,
    allowNull: false
  },
  name: {
    type: DataTypes.STRING,
    validate: {
          is: ["[a-z]",'i']       // will only allow letters                // only allow values <= 23
        },
  },
  email: {
    type: DataTypes.STRING
  },
  address: {
    type: DataTypes.STRING
  },
  phone: {
    type: DataTypes.STRING
  }
}, {
  tableName: 'customer'
});

module.exports = Customer;