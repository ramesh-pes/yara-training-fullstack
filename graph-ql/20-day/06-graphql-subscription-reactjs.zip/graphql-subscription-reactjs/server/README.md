npm i #Alternatively yarn

npm start #Alternatively yarn start

```

For any issues with nodemon, install it globally.

```sh
npm install nodemon -g # Alternatively yarn global add nodemon

```
-----
query{
  channels {
    id
  }
}
-----