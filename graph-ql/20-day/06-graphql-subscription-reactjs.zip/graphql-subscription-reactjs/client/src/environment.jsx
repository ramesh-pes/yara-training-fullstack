
// export const Host = "192.168.0.2"
export const Host = "localhost"
export const Port = "8090";

export const BASE_API = "http://"+Host+":"+Port+"/";
export const WSHost = "ws://"+Host+":"+Port+"/query";
