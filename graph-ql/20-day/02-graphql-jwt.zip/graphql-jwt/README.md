Request 1
=======
mutation{
  Register(name:"Vivek", email:"vivek2@pyther.com",password:"vivek")
}

Request 2
----
mutation{
  Login(email:"vivek@pyther.com",password:"vivek"){
  accessToken
  }
}


Request 3
----
{
  "data": {
    "Login": {
      "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzLCJpYXQiOjE2MDE1NjU0MjksImV4cCI6MTYwMTU2NjMyOX0.ojlQBuaque58s5mH4eO318VUmJLHQdaRfQziuxuv6-w"
    }
  }
}

======
Request 4
------
{
  Me
}
---
Query Variable
---
{
"authorization":"bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzLCJpYXQiOjE2MDE1NjU0MjksImV4cCI6MTYwMTU2NjMyOX0.ojlQBuaque58s5mH4eO318VUmJLHQdaRfQziuxuv6-w"
}
----