const { GraphQLObjectType } = require('graphql')
const baconMutation = require('../model/bacon/mutations')
const customerMutation = require('../model/customer/mutations')

module.exports = new GraphQLObjectType({
    name: 'RootMutationsType',
    fields: {
        addBacon: baconMutation.addBacon,
        updateBacon: baconMutation.updateBacon,
        addCustomer: customerMutation.addCustomer,
        updateCustomer: customerMutation.updateCustomer
    }
})