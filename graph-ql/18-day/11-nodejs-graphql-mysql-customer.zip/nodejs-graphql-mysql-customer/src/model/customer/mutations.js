const { 
    GraphQLNonNull,
    GraphQLString,
    GraphQLList,
    GraphQLID,
    GraphQLFloat
} = require('graphql')
const type = require('./type')
const Customer = require('./customer')

// Defines the mutations
module.exports = {
    addCustomer: {
        type,
        args: {
            name:   { type: new GraphQLNonNull(GraphQLString) },
            email:   { type: new GraphQLNonNull(GraphQLString) },
            phone:   { type: new GraphQLNonNull(GraphQLString) },
            address:   { type: new GraphQLNonNull(GraphQLString) }
        },
        resolve: Customer.createEntry.bind(Customer)
    },
    updateCustomer: {
        type,
        args: {
            id:     { type: GraphQLID },
            name:   { type:new GraphQLNonNull(GraphQLString) },
            email:   { type:new GraphQLNonNull(GraphQLString) },
            phone:   { type:new GraphQLNonNull(GraphQLString) },
            address:   { type:new GraphQLNonNull(GraphQLString) }
        },
        resolve: Customer.updateEntry.bind(Customer)
    }
}
