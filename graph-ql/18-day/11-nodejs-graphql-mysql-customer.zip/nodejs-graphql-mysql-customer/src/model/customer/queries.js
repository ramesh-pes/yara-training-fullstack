const { GraphQLList,
        GraphQLID,
        GraphQLString,
        GraphQLFloat } = require('graphql')
const type = require('./type')
const mutation = require('./mutations')
const Customer = require("./customer")

// Defines the queries
module.exports = {
    customers: {
        type: new GraphQLList(type),
        args: {
            email: {
                type: GraphQLString
            },
            name: {
                type: GraphQLString
            },
            phone: {
                type: GraphQLString
            },
            address: {
                type: GraphQLString
            },
           
        },
        resolve: Customer.findMatching.bind(Customer)
    },
    customer: {
        type,
        args: {
            id: {
                type: GraphQLID
            }
        },
        resolve: Customer.getByID.bind(Customer)
    }
}