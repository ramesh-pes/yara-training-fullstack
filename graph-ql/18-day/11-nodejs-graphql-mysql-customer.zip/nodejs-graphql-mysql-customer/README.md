# Access GraphQLi
http://localhost:4000/graphql
```

Please remember to export the example SQL schema located in ./sql/exapp.sql

## Example operations

#### Show all bacons
```js
{
  bacons {
    id,
    type,
    price
  }
}
```

### Filter bacons by price
```js
{
  bacons(price: 25) {
    id,
    type,
    price
  }
}
```

### Gets a bacon by its ID
```js
{
  bacon(id: 1) {
    id,
    type,
    price
  }
}
```

### Adds a new bacon
```js
mutation {
  addBacon(type: "truffy", price: 99) {
    id,
    type
    price
  }
}
```

### Updates a bacon
```js
mutation {
  updateBacon(id: 1, type: "musky", price: 1) {
    id,
    type
    price
  }
}
```
