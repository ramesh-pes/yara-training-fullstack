var Sequelize = require('sequelize');
var mysql = require('mysql');
var _ = require('lodash');

var Conn = new Sequelize('nodejs', 'root', 'smartant', {
    host: 'localhost',
    dialect: 'mysql'
});

var Sectors = Conn.define('sectors', {
    name: {
        type: Sequelize.STRING,
        allowNull: false
    }
});

Sectors.sync({force: true}).then(function () {
  // Table created
  return Sectors.create({
    name: 'test'
  });
});

exports.default = Conn;