var express = require('express');
var router = express.Router();
var customerService = require('../services/customer-service');
var customerSqlService = require('../services/customer-mysql');
var customerNoSqlService = require('../services/customer-mongodb');

router.get('/about', function(req, res, next) {
  res.render('index', { title: 'About',user:'test',name:req.session.user});
});

router.get('/customer', function(req, res, next) {
	let callback = function(list){
		res.render('customer', { title: 'Customer',data:list,name:req.session.user});
	}
	customerNoSqlService.getCustomers(callback);
});

router.get('/customer/add', function(req, res, next) {
  res.render('add-customer', { title: 'Add Customer'});
});

router.get('/customer/edit/:id', function(req, res, next) {
	let callback = function(result){
	  res.render('edit-customer', { title: 'Update Customer', customer:result});
  }
  customerNoSqlService.getCustomerById(req.params.id,callback);
});

router.get('/customer/search/:field/', function(req, res, next) {
	res.redirect("/customer");
});

router.get('/customer/search/:field/:searchWord', function(req, res, next) {
  let callback = function(result){
	 res.render('customer', { title: 'Customer',data:result});
  };

  customerNoSqlService.getCustomerBySearch(req.params.field,req.params.searchWord,callback);
});


module.exports = router;
