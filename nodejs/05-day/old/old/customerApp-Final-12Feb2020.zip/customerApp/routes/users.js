var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//users/login
router.post('/login', function(req, res, next) {
	console.log(req.body);
	if(req.body.username == req.body.password){
		req.session.user = req.body.username;
		console.log("req.session.user::"+req.session.user);
		res.send({result:'success', msg:"successfully signed in."});
	}else{
		res.send({result:'fail', msg:"login failed, invalid username or password"});
	}
});

module.exports = router;
