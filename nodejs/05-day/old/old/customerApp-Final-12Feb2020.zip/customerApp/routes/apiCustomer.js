var express = require('express');
var router = express.Router();
var customerService = require('../services/customer-service');
var customerSqlService = require('../services/customer-mysql');
var customerNoSqlService = require('../services/customer-mongodb');

//GET | http://localhost:3000/api/customer | should list all customers 
router.get('/', function(req, res, next) {
  let callback = function(list){
   res.send(list);
  }  
  customerNoSqlService.getCustomers(callback);
});

//POST | http://localhost:3000/api/customer | customer data | add customer
router.post('/', function(req, res, next) {
  let callback = function(result){
    console.log(result);
    res.send(result);
  }
  customerNoSqlService.addCustomer(req.body,callback);
});

// PUT  | http://localhost:3000/api/customer | customer data | update customer
router.put('/', function(req, res, next) {
  let callback = function(result){
    res.send(result);
  }
  customerNoSqlService.updateCustomer(req.body,callback);
});

// DELETE | http://localhost:3000/api/customer/:id | customer data | delete  customer of id
router.delete('/', function(req, res, next) {
	let callback = function(result){
    res.send(result);
  }
  customerNoSqlService.deleteCustomer(req.body.id,callback);
});

//GET | http://localhost:3000/api/customer/7878 | fetch record of ID 7878
router.get('/:id', function(req, res, next) {
   let callback = function(result){
    res.send(result);
  }
  customerNoSqlService.getCustomerById(req.params.id,callback);
});

//GET | http://localhost:3000/api/customer/name/vivek | fetch records of name vivek
router.get('/name/:name', function(req, res, next) {
  res.send(customerService.getCustomerByName(req.params.name));
});

// GET | http://localhost:3000/api/customer/email/vivek@gmail.com | fetch record of name vivek
router.get('/email/:email', function(req, res, next) {
  res.send(customerService.getCustomerByEmail(req.params.email));
});

module.exports = router;
