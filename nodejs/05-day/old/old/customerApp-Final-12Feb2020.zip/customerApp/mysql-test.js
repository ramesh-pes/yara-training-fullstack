var mysql      = require('mysql');
//npm i mysql
// npm install mysql

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'smartant',
  database : 'nodejs'
});
 
connection.connect();
 
connection.query('SELECT * from customer', function (error, results, fields) {
  if (error) throw error;
  for (var i = 0; i < results.length; i++) {
  	console.log(results[i].name);
  }
});
 
connection.end();