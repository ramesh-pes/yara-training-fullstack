var service ={};

let customers =[
{id:1,name:'Vivek',email:'vivek@gmail.com',address:'India',phone:'8734234567'},
{id:2,name:'Rama',email:'rama@gmail.com',address:'Delhi,India',phone:'8798934567'},
{id:3,name:'Ramesh',email:'ramesh@gmail.com',address:'Delhi,India',phone:'8798934567'}
];

service.getCustomers = function() {
	return customers;
};

service.getCustomersBySearch = function(field,keyword) {
	if(field == "name"){
		return service.getCustomerByName(keyword);
	}else if(field == "email"){
		return service.getCustomerByEmail(keyword);
	}else if(field == "phone"){
		return service.getCustomerByPhone(keyword);
	}else if(field == "address"){
		return service.getCustomerByAddress(keyword);
	}
	return customers;
};

service.getCustomerById = function(id) {
	let customer = {};
	for (var i = 0; i < customers.length; i++) {
		if(id == customers[i].id){
			return customers[i];
		}
	}
	return customer;
};

service.getCustomerByName = function(name) {
	let customerList = [];
	for (var i = 0; i < customers.length; i++) {
		if(customers[i].name.toLowerCase().startsWith(name.toLowerCase())){
			customerList.push(customers[i]);
		}
	}
	return customerList;
};

service.getCustomerByEmail = function(email) {
	let customerList = [];
	for (var i = 0; i < customers.length; i++) {
		if(customers[i].email.toLowerCase().startsWith(email.toLowerCase())){
			customerList.push(customers[i]);
		}
	}
	return customerList;
};

service.getCustomerByPhone = function(phone) {
	let customerList = [];
	for (var i = 0; i < customers.length; i++) {
		if(customers[i].phone.toLowerCase().startsWith(phone.toLowerCase())){
			customerList.push(customers[i]);
		}
	}
	return customerList;
};
service.getCustomerByAddress = function(address) {
	let customerList = [];
	for (var i = 0; i < customers.length; i++) {
		if(customers[i].address.toLowerCase().startsWith(address.toLowerCase())){
			customerList.push(customers[i]);
		}
	}
	return customerList;
};
service.addCustomer = function(customer) {
	customer.id  = Math.round(Math.random(898989) * 10000);
	customers.push(customer)
	return {result:"success", msg:'customer added successfully'};
};

service.deleteCustomer = function(id) {
	let tempCustomers = [];
	for (var i = 0; i < customers.length; i++) {
		if(customers[i].id != id){
			tempCustomers.push(customers[i]);
		}
	}
	customers = tempCustomers;
	return {result:"success", msg:'customer deleted successfully'};
};

service.updateCustomer = function(customer) {
	console.log(">> updateCustomer "+ JSON.stringify(customer));
	for (var i = 0; i < customers.length; i++) {
		if(customers[i].id == customer.id){
			customers[i] = customer;
			break;
		}
	}
	return {result:"success", msg:'customer updated successfully'};
};

module.exports = service;