var mysql = require('mysql');

var service = {};
var pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password : 'smartant',
    port : 3306, //port mysql
    database:'nodejs',
    connectionLimit: 10,
    supportBigNumbers: true
});

//async 
service.getCustomers = function(callback){
  var sql = "SELECT * FROM customer";
  pool.getConnection(
  	function(err, connection) {
    if(err) { console.log(err); callback([]); return; }
    connection.query(sql, function(err, results) {
      connection.release();
      if(err) { console.log(err); callback([]); return; }
      callback(results);
    });
  });
};

service.getCustomersBySearch = function(field,keyword) {
  if(field == "name"){
    return service.getCustomerByName(keyword);
  }else if(field == "email"){
    return service.getCustomerByEmail(keyword);
  }else if(field == "phone"){
    return service.getCustomerByPhone(keyword);
  }else if(field == "address"){
    return service.getCustomerByAddress(keyword);
  }
  return customers;
};

service.getCustomerByName = function(name) {
  let customerList = [];
  for (var i = 0; i < customers.length; i++) {
    if(customers[i].name.toLowerCase().startsWith(name.toLowerCase())){
      customerList.push(customers[i]);
    }
  }
  return customerList;
};

service.getCustomerByEmail = function(email) {
  let customerList = [];
  for (var i = 0; i < customers.length; i++) {
    if(customers[i].email.toLowerCase().startsWith(email.toLowerCase())){
      customerList.push(customers[i]);
    }
  }
  return customerList;
};

service.getCustomerByPhone = function(phone) {
  let customerList = [];
  for (var i = 0; i < customers.length; i++) {
    if(customers[i].phone.toLowerCase().startsWith(phone.toLowerCase())){
      customerList.push(customers[i]);
    }
  }
  return customerList;
};
service.getCustomerByAddress = function(address) {
  let customerList = [];
  for (var i = 0; i < customers.length; i++) {
    if(customers[i].address.toLowerCase().startsWith(address.toLowerCase())){
      customerList.push(customers[i]);
    }
  }
  return customerList;
};

service.getCustomerBySearch = function(field, searchText, callback) {
  var recordList = [];
  var sql = "SELECT * FROM customer where "+field+" like '%"+searchText+"%'";
  console.log("sql:"+sql);
  pool.getConnection(function(err, connection) {
    if(err) { console.log(err); callback({}); return; }
    // make the query
    connection.query(sql, function(err, results) {
      connection.release();
      if(err) { console.log(err); callback({}); return; }
      callback(results);
    });
  });
};

service.addCustomer = function(customer,callback) {
        pool.getConnection(function(err, connection) {
        if(err) { console.log(err); callback({result:"fail"}); return; }
        connection.query("INSERT INTO customer set ? ",customer, function(err, results) {
          if(err){
           console.log("Error Selecting : %s ",err );
           callback({result:"fail"});
          }else{
           callback({result:"success"});
         }
      });
    });
};

service.deleteCustomer = function(id,callback){
  var sql = "delete FROM customer where id='"+id+"'";
  pool.getConnection(function(err, connection) {
    if(err) { console.log(err); callback({result:"fail"}); return; }
    // make the query
    connection.query(sql, function(err, results) {
      connection.release();
      if(err) { console.log(err); callback({result:"fail"}); return; }
      callback({result:"success"});
    });
  });
};
service.getCustomerById = function(id,callback){
  var record = {};
  var sql = "SELECT * FROM customer where id='"+id+"'";
  console.log("sql:"+sql);
  pool.getConnection(function(err, connection) {
    if(err) { console.log(err); callback({}); return; }
    // make the query
    connection.query(sql, function(err, results) {
      connection.release();
      if(err) { console.log(err); callback({}); return; }
      if(results.length == 0){
        callback(record);
      }
      callback(results[0]);
    });
  });

};
service.updateCustomer = function(customer,callback){
         pool.getConnection(function(err, connection) {
        if(err) { console.log(err); callback({result:"fail"}); return; }
        connection.query("UPDATE customer set ? WHERE id = ? ",[customer,customer.id], function(err, results) {
          if(err){
           console.log("Error Selecting : %s ",err );
           callback({result:"fail"});
          }else{
           callback({result:"success"});
         }
      });
    });
};

module.exports=service; 
