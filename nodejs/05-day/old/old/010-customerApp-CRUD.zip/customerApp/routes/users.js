var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/authenticate', function(req, res, next) {
	if(typeof(req.body.username) != 'undefined' &&
		req.body.username == req.body.password ){
		res.send({result:'success', msg:"user login successfully"});
	}else{
		res.send({result:'fail', msg:"user login failed"});
	}
});

module.exports = router;
