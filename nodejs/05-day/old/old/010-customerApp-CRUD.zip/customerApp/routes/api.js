var express = require('express');
var router = express.Router();
var customerService = require('../service/customer-service');
var customerMysql = require('../service/customer-mysql');


router.get('/', function(req, res, next) {
  res.send('This is API end point.');
});

router.get('/customer', function(req, res, next) {
 customerMysql.getCustomers().then(
   function(result){
   res.send(result);
 });
});

// /api/customer  method POST
router.post('/customer', function(req, res, next) {
  customerMysql.addCustomer(req.body).then(function(result){
    res.send({result:'success', msg:'customer added ok'});
  });
});

// /api/customer  method PUT
router.put('/customer', function(req, res, next) {
  console.log(JSON.stringify(req.body));
  var callback = function(){
    res.send({result:'success', msg:'customer updated ok'});
  }
  customerMysql.updateCustomer(req.body,callback);
  
});

// /api/customer  method POST
router.delete('/customer', function(req, res, next) {
  console.log(JSON.stringify(req.body));
  customerMysql.deleteCustomer(req.body.id).then(
    function(data){
      res.send(data);
    });
  
});

router.get('/customer/:id', function(req, res, next) {
	console.log("id is "+req.params.id);
  var callback = function(data){
    res.send(data);
  }
  customerMysql.getCustomersById(req.params.id,callback);
});

module.exports = router;
