var express = require('express');
var customerService = require('../service/customer-service');
var customerMysql = require('../service/customer-mysql');
var router = express.Router();

router.get('/', function(req, res, next) {
	res.redirect('/login');
  //res.render('index', { title: 'Customer App' });
});

router.get('/customer/add', function(req, res, next) {
  res.render('add-customer', { title: 'Add Customer' });
});

router.get('/customer/edit/:id', function(req, res, next) {
  console.log("id:"+req.params.id);
  var callback = function(data){
    res.render('edit-customer', { title: 'Update Customer',customer:data}); 
  }
  customerMysql.getCustomerById(req.params.id,callback);
});

router.get('/dashboard', function(req, res, next) {
  res.render('index', { title: 'Dashboard' });
});


router.get('/aboutus', function(req, res, next) {
  res.render('index', { title: 'Aboutus' });
});

router.get('/customer', function(req, res, next) {
  var callback = function(data){
    res.render('customers', { title: 'Customers',data:data});
  }
  customerMysql.getCustomers().then(callback);
});

router.get('/customer/:field/:text', function(req, res, next) {
  res.render('customers', { title: 'Customers',data:customerService.getCustomersBySearch(req.params.field,req.params.text) });
});

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login' });
});

module.exports = router;
