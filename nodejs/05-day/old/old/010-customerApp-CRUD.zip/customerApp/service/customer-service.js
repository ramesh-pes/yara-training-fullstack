var service = {};

var customers = [
	{id:1,name:'Vivek',email:'vivek@gmail.com',address:'Ahmedabad, India', phone:'9724232340'},
	{id:2,name:'Samridh',email:'samdrih@gmail.com',address:'Bengaluru, India', phone:'9724237840'},
	{id:3,name:'Mahi',email:'Mahi@pyther.com',address:'Delhi, India', phone:'9728937840'}
];

service.getCustomers = function(){
	return customers;
}

service.getCustomersById = function(customerId){
	var customer = {};
	for (var i = 0; i < customers.length; i++){
		if(customers[i].id == customerId){
			customer = customers[i];
			break;
		}
	}
	return customer;
}

service.getCustomersBySearch = function(field,text){
	text = text.toLowerCase();
	var tempCustomers = []
	for (var i = 0; i < customers.length; i++){
		if(customers[i][field].toLowerCase().startsWith(text)){
			tempCustomers.push(customers[i]);
		}
	}
	return tempCustomers;
}

service.addCustomer = function(customer){
	customer.id = Math.floor(Math.random()*10000000);
	customers.push(customer);
}

service.updateCustomer = function(customer){
	for (var i = 0; i < customers.length; i++){
		if(customers[i].id == customer.id){
			customers[i] = customer;
		}
	}
}

service.deleteCustomers = function(customerId){
	var tempCustomers = [];
	for (var i = 0; i < customers.length; i++){
		if(customers[i].id != customerId){
			tempCustomers.push(customers[i]);
		}
	}
	customers = tempCustomers;
}

module.exports=service;