var express = require('express');
var customerService = require('../service/customer-service');
var customerDbService = require('../service/customerdb-service');
var customerMongoService = require('../service/customer-mongo-service');

var router = express.Router();

router.get('/customer', function (req, res) {
  //http://localhost:3000/api/customer?name=vivek&email=rama@gmail.com
  //console.log(req.query);
  var callback = function(data){
    console.log("result received.");
    res.send(data);
  }
  console.log("making a db call.");
  customerMongoService.getCustomers(callback);
})

router.put('/customer', function (req, res) {
  var callback = function(result){
      res.send(result);
  }
  customerMongoService.updateCustomer(req.body,callback)
})

router.post('/customer', function (req, res) {
  var callback = function(result){
    res.send(result);
  }
  customerMongoService.addCustomer(req.body,callback);
})


router.delete('/customer', function (req, res) {
  var callback = function(result){
    res.send(result);
  }
  customerMongoService.deleteCustomer(req.body.id,callback)
})


router.get('/customer/:id', function (req, res) {
  var callback = function(result){
    res.send(result);
  }
  customerMongoService.getCustomerById(req.params.id,callback);
})


module.exports = router;

