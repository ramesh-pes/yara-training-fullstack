var mysql = require('mysql');
var service = {}; //new Object();

service.pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password : 'smartant',
    port : 3306, //port mysql
    database:'nodejs',
    connectionLimit: 10,
    supportBigNumbers: true
});

module.exports=service;