var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'smartant',
  database : 'nodejs'
});
 
connection.connect();
 
connection.query('SELECT * from customer', function (error, results, fields) {
  if (error) throw error;
  console.log(results);
  console.log('The solution is: ', results[0].solution);
});
 
connection.end(); 