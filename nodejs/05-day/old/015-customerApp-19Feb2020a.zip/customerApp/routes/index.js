var express = require('express');
var customerService = require('../service/customer-service');
var customerMysql = require('../service/customer-mysql');
var customerMongo = require('../service/customer-mongo');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  //res.render('index', { title: 'Customer App' });
  res.redirect("/login");
});

router.get('/dashboard', function(req, res, next) {
  res.render('index', { title: 'Dashboard' });
});

router.get('/about', function(req, res, next) {
  res.render('index', { title: 'About' });
});

router.get('/customer', function(req, res, next) {
  var callback = function(data){
  	res.render('customers', { title: 'Customers',data:data});
  }
  customerMongo.getCustomers(callback);
  //customerMysql.getCustomers(callback);
  //res.render('customers', { title: 'Customers',data:customerService.getCustomers()});

});

router.get('/customer/add', function(req, res, next) {
  res.render('add-customer', { title: 'Add Customer' });
});

router.get('/customer/edit/:id', function(req, res, next) {
	var callback = function(data){
  		res.render('edit-customer', { title: 'Update Customer',customer:data});
	}
	customerMongo.getCustomerById(req.params.id,callback);
});

//   /api/customer
router.get('/customer/:field/:searchTxt', function(req, res, next) {
	var callback = function(data){
		res.render('customers', { title: 'Customers',data:data});
	}
	customerMongo.getCustomersBySearch(req.params.field, req.params.searchTxt,callback);
});



router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Customer App' });
});

module.exports = router;
