var express = require('express');
var router = express.Router();
var customerService = require('../service/customer-service');
var customerMysql = require('../service/customer-mysql');
var customerMongo = require('../service/customer-mongo');

// /api
router.get('/', function(req, res, next) {
  res.send('api url is  /');
});

//   /api/customer
router.get('/customer', function(req, res, next) {
	var callback = function(data){
		 res.send(data);
	}
 	//customerMysql.getCustomers(callback);
 	customerMongo.getCustomers(callback);
});

//   /api/customer
router.get('/customer/:field/:searchTxt', function(req, res, next) {
  	var callback = function(data){
		res.send(data);
	}
  customerMongo.getCustomersBySearch(req.params.field, req.params.searchTxt,callback)
});

//   /api/customer/:id
router.get('/customer/:id', function(req, res, next) {
	var callback = function(data){
		res.send(data);
	}
	customerMongo.getCustomerById(req.params.id,callback);
});

//   post /api/customer
router.post('/customer', function(req, res, next) {
	var callback = function(data){
		res.send(data);
	}
  	customerMongo.addCustomer(req.body,callback);
});

//   delete /api/customer
router.delete('/customer', function(req, res, next) {
	var callback = function(data){
		res.send(data);
	}
  	customerMongo.deleteCustomer(req.body.id,callback);
});

//  put /api/customer
router.put('/customer', function(req, res, next) {
	var callback = function(data){
		res.send(data);
	}
  	customerMongo.updateCustomer(req.body,callback);
});

module.exports = router;
