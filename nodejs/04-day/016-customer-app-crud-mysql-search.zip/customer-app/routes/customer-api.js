var express = require('express');
var router = express.Router();
var customerModel = require('../model/customer');
var customerMySQL = require('../model/customer-mysql');

router.get('/', function (req, res) {
	let callback = (records) =>{
		console.log("records"+records);
		res.send(records);
	}
	customerMySQL.getCustomers().then(callback);
});

router.get('/all', function (req, res) {
	let callback = (records) =>{
		res.send(records);
	}
	customerMySQL.getRecords(callback);
});

router.put('/', function (req, res) {
	let customer = req.body;
	let callback = (result) => { res.send(result); };
	customerMySQL.updateRecord(customer).then(callback);
});

router.delete('/', function (req, res) {
	let customer = req.body;
	customerMySQL.deleteCustomer(customer.id).then((result)=> {
		res.send(result);
	})	
});

router.post('/', function (req, res) {
	console.log("post .. customer");
	let callback = (result) => res.send(result);
	customerMySQL.addCustomer(req.body).then(callback);
});

module.exports = router;








