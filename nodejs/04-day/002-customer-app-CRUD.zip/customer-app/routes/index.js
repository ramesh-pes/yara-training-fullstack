var express = require('express');
var router = express.Router();
var customerModel = require('../model/customer');

router.get('/', function(req, res, next) {
	res.redirect("/login");
 // res.render('index', { title: 'Cusotmer App' });
});

// /rama + /home = /rama/home
router.get('/home', function(req, res, next) {
  res.render('home', { title: 'Home Page' });
});

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Login' });
});

router.get('/about', function(req, res, next) {
  res.render('home', { title: 'About' });
});

router.get('/student', function(req, res, next) {
  res.render('home', { title: 'Student' });
});

router.get('/customer', function(req, res, next) {
  res.render('customer', { title: 'Customers' , customers:customerModel.getRecords() });
});

router.get('/customer/add', function(req, res, next) {
  res.render('customerAdd', { title: 'Add Customer' , customers:customerModel.getRecords() });
});

router.get('/customer/search/:field/:text', function(req, res, next) {
  res.render('customer', 
  	{ title: 'Customers', 
  	customers:customerModel.getRecordsBySearch(req.params.field,req.params.text)});
});

router.get('/customer/edit/:id', function(req, res, next) {
	console.log("id:"+req.params.id);
  res.render('customerEdit', { title: 'Update Customer', customer: customerModel.getRecordById(req.params.id)});
});

module.exports = router;












